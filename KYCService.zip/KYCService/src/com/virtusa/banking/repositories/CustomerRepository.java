package com.virtusa.banking.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.banking.models.Customer;

public interface CustomerRepository extends JpaRepository<Customer,Long>{

	@Query("select customer from Customer customer Where customer.firstName=:fname")
	public Customer findByName(@Param("fname") String fname);
	
	
}
