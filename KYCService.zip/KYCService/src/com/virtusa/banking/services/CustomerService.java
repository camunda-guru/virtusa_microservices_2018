package com.virtusa.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.banking.models.Customer;
import com.virtusa.banking.repositories.CustomerRepository;

@Service
public class CustomerService {
    @Autowired
	private CustomerRepository repo;
	
    //save object -- insert query
    public Customer saveCustomer(Customer customer)
    {
    	return repo.save(customer);
    }
    //retrieve all
    public List<Customer> getAllCustomers()
    {
    	return repo.findAll();
    }
    
    //findbyid
    
    public Customer customerfindbyId(long id)
    {
    	return repo.findById(id).orElse(null);
    }
	
 //findbyid
    
    public void customerdeletebyId(long id)
    {
    	repo.deleteById(id);
    }
    
    //findbyname
    public Customer findByCustomerName(String fname)
    {
    	return repo.findByName(fname);
    }
    
    
    
}
