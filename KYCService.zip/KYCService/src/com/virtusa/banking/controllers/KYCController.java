package com.virtusa.banking.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.banking.models.Customer;
import com.virtusa.banking.services.CustomerService;

@RestController
@CrossOrigin("*")
public class KYCController {
    @Autowired
	private CustomerService service;
	@GetMapping("/home")
	public String home()
	{
		return "Ready to Rock!!!!";
	}
	
	@PostMapping("/addcustomer")
	public @ResponseBody Customer addCustomerData(@RequestBody Customer customer)
	{
		return service.saveCustomer(customer);
	}
	
	@GetMapping("/getall")
	public List<Customer> getAllCustomers()
	{
		return service.getAllCustomers();
	}
	
	
	@GetMapping("/getcustomerbyId/{Id}")
	public Customer getcustomerById(@PathVariable("Id") long Id)
	{
		return service.customerfindbyId(Id);
	}
	@GetMapping("/getcustomerbyFirstName/{fname}")
	public Customer getcustomerByName(@PathVariable("fname") String fname)
	{
		return service.findByCustomerName(fname);
	}
	
	@GetMapping("/deletecustomerbyId/{Id}")
	public String deletecustomerById(@PathVariable("Id") long Id)
	{
		 service.customerdeletebyId(Id);
		 return "Customer Deleted for the given Id = "+ Id;
	}
	
	
}
